﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaroGame
{
    class SoLieu
    {
        public static int CHESS_SIZE = 24;
        public static int CHESS_BOARD_COLUMN = 18;
        public static int CHESS_BOARD_ROW = 16;


    }
}
