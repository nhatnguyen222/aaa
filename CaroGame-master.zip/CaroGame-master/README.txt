# CaroGame
Áp dụng giải thuật minimax cho chức năng Người vs Máy